function exitosa(){

    alert("El registro se ha completado de forma exitosa")

    window.location("../../login.php")

}